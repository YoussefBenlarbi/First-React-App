function Module({nomModule,moyenne}){
    // const {nomModule} = props ;
    return (
        <li >{nomModule} {" : "} {moyenne}</li>
    )
}

export default Module;